class GradesEntry:
    def __init__(self, clcode = "12345",
                 subj ="Name of the Subject",
                 units="1",
                 gpercent = "0"):
        self.clcode = clcode
        self.subj = subj
        self.units = units
        self.gpercent = gpercent

